
<?php
require "autenticacion.php";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Aplicación</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link 
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" 
        rel="stylesheet"
    >

    <style>
        body {
            background: linear-gradient(180deg, #f4f6f9, #e9ecef);
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
        }

        /* Navbar */
        .navbar {
            background: linear-gradient(90deg, #1e1e2f, #343a40);
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.25rem;
            letter-spacing: 1px;
        }

        .navbar-brand span {
            color: #0d6efd;
        }

        /* Dropdown glass effect */
        .dropdown-menu {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(8px);
            border-radius: 1rem;
            border: none;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .dropdown-item {
            border-radius: 0.5rem;
            transition: all 0.25s ease;
        }

        .dropdown-item:hover {
            background: #0d6efd;
            color: white;
            transform: translateX(6px);
        }

        /* Nav links */
        .nav-link {
            position: relative;
            transition: color 0.3s;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: 0;
            width: 0%;
            height: 2px;
            background-color: #0d6efd;
            transition: width 0.3s;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        /* Logout */
        .nav-link.text-danger {
            background-color: rgba(220, 53, 69, 0.15);
            border-radius: 50px;
            padding: 0.4rem 1rem;
            transition: all 0.3s;
        }

        .nav-link.text-danger:hover {
            background-color: #dc3545;
            color: white !important;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark shadow-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            ⚙️ <span>Mi</span> Aplicación
        </a>

        <button 
            class="navbar-toggler" 
            type="button" 
            data-bs-toggle="collapse" 
            data-bs-target="#navbarNavDropdown"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ms-auto gap-2">

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        Base de datos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="db_connect.php">Conectar</a></li>
                        <li><a class="dropdown-item" href="db_create.php">Crear</a></li>
                        <li><a class="dropdown-item" href="db_drop.php">Borrar</a></li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        Tabla
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="table_create_guests.php">Crear tabla</a></li>
                        <li><a class="dropdown-item" href="table_check_exists.php">Verificar existencia</a></li>
                        <li><a class="dropdown-item" href="table_drop.php">Borrar tabla</a></li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        Datos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="form_insert.php">Insertar</a></li>
                        <li><a class="dropdown-item" href="form_select_lastname.php">Buscar por apellido</a></li>
                        <li><a class="dropdown-item" href="form_select_order.php">Ver todos ordenados</a></li>
                        <li><a class="dropdown-item" href="form_delete.php">Borrar por ID</a></li>
                        <li><a class="dropdown-item" href="form_update_lastname.php">Actualizar apellido</a></li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-danger fw-semibold" href="logout.php">
                        Cerrar sesión
                    </a>
                </li>

            </ul>
        </div>
    </div>
</nav>

<script 
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>
