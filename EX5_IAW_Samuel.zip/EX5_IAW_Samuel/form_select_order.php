<?php
include "cabecera.php";
?>
<form action="data_select_orderby.php" method="post">
  Orden:
  <select name="orden">
    <option value="ASC">Ascendente</option>
    <option value="DESC">Descendente</option>
  </select>
  <input type="submit" value="Ver datos">
</form>
