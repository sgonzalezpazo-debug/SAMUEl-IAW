<?php
include "cabecera.php";
?>
<form action="data_select_where.php" method="post">
  Apellido: <input type="text" name="lastname"><br>
  <input type="submit" value="Buscar">
</form>


