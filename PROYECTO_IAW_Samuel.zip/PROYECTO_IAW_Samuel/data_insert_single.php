<?php
// data_insert_single.php - Insertar un futbolista
include "cabecera.php";
include "recoge.php";

// Recoger datos
$nombre = recoge('nombre');
$apellido = recoge('apellido');
$posicion = recoge('posicion');
$equipo = recoge('equipo');
$nacionalidad = recoge('nacionalidad');
$edad = recoge('edad');
$valor = recoge('valor_mercado');

// Conectar
require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Preparar consulta segura
$stmt = $conn->prepare("INSERT INTO Futbolistas (nombre, apellido, posicion, equipo, nacionalidad, edad, valor_mercado) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssid", $nombre, $apellido, $posicion, $equipo, $nacionalidad, $edad, $valor);

if ($stmt->execute()) {
    echo "<div class='alert alert-success'>Futbolista agregado correctamente</div>";
    echo "<p>ID asignado: " . $stmt->insert_id . "</p>";
} else {
    echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
}

$stmt->close();
$conn->close();
?>

<a href="form_insert.php" class="btn btn-primary">Agregar otro</a>
<a href="data_select_all.php" class="btn btn-secondary">Ver todos</a>
<a href="dashboard.php" class="btn btn-secondary">Inicio</a>

<?php include "pie.php"; ?>