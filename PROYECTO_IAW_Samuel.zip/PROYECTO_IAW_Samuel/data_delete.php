<?php
// data_delete.php - Eliminar futbolista por ID
include "cabecera.php";
include "recoge.php";

$id = recoge('id');

if (!$id) {
    echo "<div class='alert alert-danger'>Debe especificar un ID</div>";
    include "pie.php";
    exit();
}

require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Prepared statement para eliminar
$stmt = $conn->prepare("DELETE FROM Futbolistas WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo "<div class='alert alert-success'>Futbolista con ID $id eliminado</div>";
    } else {
        echo "<div class='alert alert-warning'>No existe futbolista con ID $id</div>";
    }
} else {
    echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
}

$stmt->close();
$conn->close();
?>

<a href="form_delete.php" class="btn btn-primary">Eliminar otro</a>
<a href="data_select_all.php" class="btn btn-secondary">Ver todos</a>
<a href="dashboard.php" class="btn btn-secondary">Inicio</a>

<?php include "pie.php"; ?>