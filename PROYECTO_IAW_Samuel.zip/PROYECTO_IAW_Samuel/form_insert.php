<?php
// form_insert.php - Formulario para insertar futbolista
include "cabecera.php";
?>

<h3>Nuevo Futbolista</h3>

<form action="data_insert_single.php" method="post" class="mt-4">
    <div class="row">
        <div class="col-md-6 mb-3">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>
        <div class="col-md-6 mb-3">
            <label>Apellido:</label>
            <input type="text" name="apellido" class="form-control" required>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6 mb-3">
            <label>Posición:</label>
            <select name="posicion" class="form-control">
                <option value="Portero">Portero</option>
                <option value="Defensa">Defensa</option>
                <option value="Centrocampista">Centrocampista</option>
                <option value="Delantero">Delantero</option>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label>Equipo:</label>
            <input type="text" name="equipo" class="form-control" required>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-4 mb-3">
            <label>Nacionalidad:</label>
            <input type="text" name="nacionalidad" class="form-control" required>
        </div>
        <div class="col-md-4 mb-3">
            <label>Edad:</label>
            <input type="number" name="edad" class="form-control" min="16" max="50" required>
        </div>
        <div class="col-md-4 mb-3">
            <label>Valor (€M):</label>
            <input type="number" step="0.1" name="valor_mercado" class="form-control" required>
        </div>
    </div>
    
    <button type="submit" class="btn btn-success">Guardar</button>
    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
</form>

<?php include "pie.php"; ?>