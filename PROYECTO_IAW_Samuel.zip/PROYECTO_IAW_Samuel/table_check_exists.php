<?php
// table_check_exists.php - Verificar existencia de tabla
include "cabecera.php";

require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

$sql = "SHOW TABLES LIKE 'Futbolistas'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<div class='alert alert-success'>✅ La tabla 'Futbolistas' existe</div>";
} else {
    echo "<div class='alert alert-danger'>❌ La tabla 'Futbolistas' NO existe</div>";
    echo "<a href='db_create.php' class='btn btn-primary mt-2'>Crear tabla</a>";
}

mysqli_close($conn);
?>

<a href="dashboard.php" class="btn btn-secondary">Volver</a>

<?php include "pie.php"; ?>