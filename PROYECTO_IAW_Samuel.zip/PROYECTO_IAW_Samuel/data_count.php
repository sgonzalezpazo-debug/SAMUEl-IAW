<?php
// data_count.php - Contar futbolistas
include "cabecera.php";

require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

$sql = "SELECT COUNT(*) as total FROM Futbolistas";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

echo "<h3>Estadísticas</h3>";
echo "<div class='alert alert-info'>";
echo "<h4>Total futbolistas: " . $row['total'] . "</h4>";
echo "</div>";

// Otras estadísticas simples
$sql = "SELECT COUNT(*) as port FROM Futbolistas WHERE posicion = 'Portero'";
$result = mysqli_query($conn, $sql);
$port = mysqli_fetch_assoc($result);

$sql = "SELECT AVG(valor_mercado) as promedio FROM Futbolistas";
$result = mysqli_query($conn, $sql);
$prom = mysqli_fetch_assoc($result);

echo "<div class='row mt-3'>";
echo "<div class='col-md-4'>Porteros: " . $port['port'] . "</div>";
echo "<div class='col-md-4'>Promedio valor: €" . number_format($prom['promedio'], 2) . "M</div>";
echo "</div>";

mysqli_close($conn);
?>

<a href="dashboard.php" class="btn btn-primary mt-3">Volver</a>

<?php include "pie.php"; ?>