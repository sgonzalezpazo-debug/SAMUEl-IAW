<?php
// database.php - Versión ultra simple
// ====================================

// Solo una función para conectar
function conectarBD() {
    require_once 'config.php';
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Error conectando a la base de datos: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// Función simple para crear BD y tabla
function setupDatabase() {
    require_once 'config.php';
    
    // Crear conexión sin base de datos
    $conn = new mysqli($servername, $username, $password);
    
    if ($conn->connect_error) {
        die("Error: " . $conn->connect_error);
    }
    
    // Crear BD
    $sql = "CREATE DATABASE IF NOT EXISTS $dbname CHARACTER SET utf8mb4";
    $conn->query($sql);
    
    // Usar la BD
    $conn->select_db($dbname);
    
    // Crear tabla
    $sql = "CREATE TABLE IF NOT EXISTS Futbolistas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(50),
        apellido VARCHAR(50),
        posicion VARCHAR(20),
        equipo VARCHAR(100),
        nacionalidad VARCHAR(50),
        edad INT,
        valor_mercado DECIMAL(10,2)
    )";
    
    $conn->query($sql);
    $conn->close();
    
    return true;
}
?>