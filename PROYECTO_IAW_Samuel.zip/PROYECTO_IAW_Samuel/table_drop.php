<?php
// table_drop.php - Eliminar tabla (con confirmación)
include "cabecera.php";

// Solo si se confirma
if (isset($_POST['confirmar']) && $_POST['confirmar'] === 'SI') {
    require_once "config.php";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    $sql = "DROP TABLE IF EXISTS Futbolistas";
    if (mysqli_query($conn, $sql)) {
        echo "<div class='alert alert-success'>Tabla 'Futbolistas' eliminada</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
    }
    
    mysqli_close($conn);
    echo "<a href='db_create.php' class='btn btn-primary'>Crear tabla nueva</a>";
} else {
    // Mostrar formulario de confirmación
    ?>
    <div class="alert alert-danger">
        <h4>⚠️ Advertencia</h4>
        <p>Está a punto de eliminar la tabla 'Futbolistas'.</p>
        <p><strong>Esta acción eliminará TODOS los datos permanentemente.</strong></p>
        
        <form method="post" class="mt-3">
            <p>Para confirmar, escriba "SI" en mayúsculas:</p>
            <input type="text" name="confirmar" class="form-control mb-2" pattern="SI" required>
            <button type="submit" class="btn btn-danger">Eliminar tabla</button>
            <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
    <?php
}
?>

<?php include "pie.php"; ?>