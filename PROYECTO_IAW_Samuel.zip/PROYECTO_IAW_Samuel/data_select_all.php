<?php
// data_select_all.php - Mostrar todos los futbolistas
include "cabecera.php";

// Conectar
require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Consultar
$sql = "SELECT * FROM Futbolistas ORDER BY ID";
$result = mysqli_query($conn, $sql);

echo "<h3>Lista de Futbolistas</h3>";

if (mysqli_num_rows($result) > 0) {
    echo "<table class='table table-striped mt-3'>";
    echo "<tr class='table-dark'><th>ID</th><th>Nombre</th><th>Apellido</th><th>Posición</th><th>Equipo</th><th>Edad</th><th>Valor (€M)</th></tr>";
    
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
        echo "<td>" . htmlspecialchars($row['apellido']) . "</td>";
        echo "<td>" . $row['posicion'] . "</td>";
        echo "<td>" . htmlspecialchars($row['equipo']) . "</td>";
        echo "<td>" . $row['edad'] . "</td>";
        echo "<td>" . $row['valor_mercado'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='alert alert-warning'>No hay futbolistas registrados</div>";
}

mysqli_close($conn);
?>

<a href="dashboard.php" class="btn btn-primary">Volver</a>

<?php include "pie.php"; ?>