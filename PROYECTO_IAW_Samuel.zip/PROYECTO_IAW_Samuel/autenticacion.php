<?php
// autenticacion.php - Control de sesión simple
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>