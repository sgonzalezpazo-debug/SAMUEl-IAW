<?php
// db_connect.php - Probar conexión a MySQL
include "cabecera.php";

require_once "config.php";
$conn = mysqli_connect($servername, $username, $password);

if ($conn) {
    echo "<div class='alert alert-success'>✅ Conectado al servidor MySQL</div>";
    
    // Probar conexión a la base de datos
    $conn_db = mysqli_connect($servername, $username, $password, $dbname);
    if ($conn_db) {
        echo "<div class='alert alert-success'>✅ Conectado a la base de datos '$dbname'</div>";
        mysqli_close($conn_db);
    } else {
        echo "<div class='alert alert-warning'>❌ No se pudo conectar a '$dbname'</div>";
        echo "<a href='db_create.php' class='btn btn-primary'>Crear base de datos</a>";
    }
    
    mysqli_close($conn);
} else {
    echo "<div class='alert alert-danger'>❌ No se pudo conectar al servidor MySQL</div>";
}
?>

<a href="dashboard.php" class="btn btn-secondary">Volver</a>

<?php include "pie.php"; ?>