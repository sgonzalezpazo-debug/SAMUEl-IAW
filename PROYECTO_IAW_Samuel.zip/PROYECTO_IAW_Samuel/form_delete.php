<?php
// form_delete.php - Formulario eliminar
include "cabecera.php";
?>

<h3>Eliminar por ID</h3>

<form action="data_delete.php" method="post" class="mt-4">
    <div class="mb-3">
        <label>ID del futbolista:</label>
        <input type="number" name="id" class="form-control" placeholder="Ej: 1" required>
        <small class="text-muted">El ID se muestra en la lista de futbolistas</small>
    </div>
    
    <button type="submit" class="btn btn-danger">Eliminar</button>
    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
</form>

<?php include "pie.php"; ?>