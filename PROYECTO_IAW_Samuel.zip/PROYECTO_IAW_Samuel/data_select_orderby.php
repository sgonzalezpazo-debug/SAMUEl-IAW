<?php
// data_select_ordeby.php - Ordenar futbolistas por apellido
include "cabecera.php";
include "recoge.php";

$orden = strtoupper(recoge('orden'));
if ($orden !== 'ASC' && $orden !== 'DESC') {
    $orden = 'ASC'; // Por defecto
}

require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Consulta segura (whitelist)
$orden_sql = ($orden === 'DESC') ? 'DESC' : 'ASC';
$sql = "SELECT * FROM Futbolistas ORDER BY apellido $orden_sql";
$result = mysqli_query($conn, $sql);

echo "<h3>Futbolistas ordenados por apellido ($orden_sql)</h3>";

// Botones para cambiar orden
echo "<div class='mb-3'>";
echo "<a href='?orden=ASC' class='btn btn-sm btn-outline-primary'>Ascendente (A-Z)</a> ";
echo "<a href='?orden=DESC' class='btn btn-sm btn-outline-primary'>Descendente (Z-A)</a>";
echo "</div>";

if (mysqli_num_rows($result) > 0) {
    echo "<table class='table table-striped'>";
    echo "<tr class='table-dark'><th>ID</th><th>Nombre</th><th>Apellido</th><th>Equipo</th><th>Posición</th></tr>";
    
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
        echo "<td>" . htmlspecialchars($row['apellido']) . "</td>";
        echo "<td>" . htmlspecialchars($row['equipo']) . "</td>";
        echo "<td>" . $row['posicion'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='alert alert-warning'>No hay futbolistas registrados</div>";
}

mysqli_close($conn);
?>

<a href="dashboard.php" class="btn btn-primary">Volver al inicio</a>

<?php include "pie.php"; ?>