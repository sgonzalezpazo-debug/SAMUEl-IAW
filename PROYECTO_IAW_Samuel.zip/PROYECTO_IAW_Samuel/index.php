<?php
// index.php - Este archivo SIEMPRE redirige al login
session_start();

// IMPORTANTE: Forzar la redirección inmediata
header("Location: login.php");
exit();
?>