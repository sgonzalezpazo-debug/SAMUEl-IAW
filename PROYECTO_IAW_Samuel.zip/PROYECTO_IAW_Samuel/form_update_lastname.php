<?php
// form_update_lastname.php - Formulario para actualizar apellido
include "cabecera.php";
?>

<h3>Actualizar Apellido</h3>

<form action="data_update.php" method="post" class="mt-4">
    <div class="row">
        <div class="col-md-6 mb-3">
            <label>ID del futbolista:</label>
            <input type="number" name="id" class="form-control" required>
        </div>
        <div class="col-md-6 mb-3">
            <label>Nuevo apellido:</label>
            <input type="text" name="lastname" class="form-control" required>
        </div>
    </div>
    
    <button type="submit" class="btn btn-warning">Actualizar</button>
    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
</form>

<?php include "pie.php"; ?>