<?php
// cabecera.php - Solo incluye autenticación
require_once "autenticacion.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sistema Futbolistas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">⚽ Sistema Futbolistas</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">Inicio</a>
                <a class="nav-link text-danger" href="logout.php">Salir</a>
            </div>
        </div>
    </nav>
    <div class="container mt-3">