<?php
// security.php - Versión ultra simple
// ====================================

// Función para escapar HTML
function escapeHTML($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

// Validar ID numérico
function validateId($id) {
    $id = filter_var($id, FILTER_VALIDATE_INT);
    if ($id === false || $id < 1) {
        die("ID inválido");
    }
    return $id;
}

// Validar texto básico
function validateText($texto, $min = 2, $max = 100) {
    $texto = trim($texto);
    if (strlen($texto) < $min || strlen($texto) > $max) {
        die("Texto debe tener entre $min y $max caracteres");
    }
    return $texto;
}

// Verificar autenticación
function checkAuth() {
    if (!isset($_SESSION['usuario'])) {
        header('Location: login.php');
        exit();
    }
}
?>