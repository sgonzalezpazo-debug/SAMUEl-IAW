<?php
// form_select_lastname.php - Formulario buscar por apellido
include "cabecera.php";
?>

<h3>Buscar por Apellido</h3>

<form action="data_select_where.php" method="post" class="mt-4">
    <div class="mb-3">
        <label>Apellido del futbolista:</label>
        <input type="text" name="lastname" class="form-control" placeholder="Ej: Messi" required>
    </div>
    
    <button type="submit" class="btn btn-primary">Buscar</button>
    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
</form>

<?php include "pie.php"; ?>