<?php
// db_create.php - Crear base de datos y tabla
include "cabecera.php";

// Crear conexión
require_once "config.php";
$conn = mysqli_connect($servername, $username, $password);

echo "<div class='container mt-4'>";
echo "<h3>Crear Base de Datos y Tabla</h3>";

// Verificar si la base de datos ya existe
$sql_check_db = "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbname'";
$result = mysqli_query($conn, $sql_check_db);

if (mysqli_num_rows($result) > 0) {
    // La base de datos ya existe
    echo "<div class='alert alert-warning'>⚠️ La base de datos <strong>'$dbname'</strong> ya existe</div>";
    
    // Conectar a la base de datos existente
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
        echo "<div class='alert alert-danger'>Error al conectar a la base de datos existente: " . mysqli_connect_error() . "</div>";
    } else {
        // Verificar si la tabla ya existe
        $sql_check_table = "SHOW TABLES LIKE 'Futbolistas'";
        $result_table = mysqli_query($conn, $sql_check_table);
        
        if (mysqli_num_rows($result_table) > 0) {
            echo "<div class='alert alert-warning'>⚠️ La tabla <strong>'Futbolistas'</strong> ya existe en la base de datos</div>";
            echo "<div class='alert alert-info'>💡 Ambas (BD y tabla) ya están creadas. No es necesario crearlas nuevamente.</div>";
        } else {
            // Solo la tabla no existe
            echo "<div class='alert alert-info'>La base de datos existe pero la tabla no. Creando tabla...</div>";
            
            // Crear tabla futbolistas
            $sql = "CREATE TABLE Futbolistas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(50),
                apellido VARCHAR(50),
                posicion VARCHAR(20),
                equipo VARCHAR(100),
                nacionalidad VARCHAR(50),
                edad INT,
                valor_mercado DECIMAL(10,2)
            )";
            
            if (mysqli_query($conn, $sql)) {
                echo "<div class='alert alert-success'>✅ Tabla 'Futbolistas' creada exitosamente</div>";
            } else {
                echo "<div class='alert alert-danger'>❌ Error al crear tabla: " . mysqli_error($conn) . "</div>";
            }
        }
    }
} else {
    // Crear base de datos
    echo "<div class='alert alert-info'>Creando base de datos...</div>";
    $sql = "CREATE DATABASE $dbname";
    
    if (mysqli_query($conn, $sql)) {
        echo "<div class='alert alert-success'>✅ Base de datos '$dbname' creada exitosamente</div>";
        
        // Conectar a la nueva BD
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        
        if (!$conn) {
            echo "<div class='alert alert-danger'>❌ Error al conectar a la nueva base de datos</div>";
        } else {
            // Crear tabla futbolistas
            $sql = "CREATE TABLE Futbolistas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(50),
                apellido VARCHAR(50),
                posicion VARCHAR(20),
                equipo VARCHAR(100),
                nacionalidad VARCHAR(50),
                edad INT,
                valor_mercado DECIMAL(10,2)
            )";
            
            if (mysqli_query($conn, $sql)) {
                echo "<div class='alert alert-success'>✅ Tabla 'Futbolistas' creada exitosamente</div>";
            } else {
                echo "<div class='alert alert-danger'>❌ Error al crear tabla: " . mysqli_error($conn) . "</div>";
            }
        }
    } else {
        echo "<div class='alert alert-danger'>❌ Error al crear base de datos: " . mysqli_error($conn) . "</div>";
    }
}

mysqli_close($conn);

echo "<div class='mt-4'>";
echo "<a href='dashboard.php' class='btn btn-primary'><i class='fas fa-home'></i> Volver al Dashboard</a>";
echo " <a href='data_insert_multiple_prepared.php' class='btn btn-success'><i class='fas fa-upload'></i> Cargar Datos de Ejemplo</a>";
echo "</div>";
echo "</div>"; // cierre del container

include "pie.php";
?>