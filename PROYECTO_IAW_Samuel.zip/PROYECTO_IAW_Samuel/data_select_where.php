<?php
// data_select_where.php - Buscar futbolistas por apellido
include "cabecera.php";
include "recoge.php";

$apellido = recoge('lastname');

if (!$apellido) {
    echo "<div class='alert alert-warning'>Debe ingresar un apellido</div>";
    include "pie.php";
    exit();
}

require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Usar prepared statement
$stmt = $conn->prepare("SELECT * FROM Futbolistas WHERE apellido = ?");
$stmt->bind_param("s", $apellido);
$stmt->execute();
$result = $stmt->get_result();

echo "<h3>Resultados para: " . htmlspecialchars($apellido) . "</h3>";

if ($result->num_rows > 0) {
    echo "<table class='table table-striped mt-3'>";
    echo "<tr class='table-dark'><th>ID</th><th>Nombre</th><th>Apellido</th><th>Equipo</th><th>Posición</th></tr>";
    
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
        echo "<td>" . htmlspecialchars($row['apellido']) . "</td>";
        echo "<td>" . htmlspecialchars($row['equipo']) . "</td>";
        echo "<td>" . $row['posicion'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='alert alert-warning'>No se encontraron resultados</div>";
}

$stmt->close();
$conn->close();
?>

<a href="form_select_lastname.php" class="btn btn-primary">Nueva búsqueda</a>
<a href="dashboard.php" class="btn btn-secondary">Inicio</a>

<?php include "pie.php"; ?>