<?php
// dashboard.php - Página principal después del login
include "cabecera.php";
?>

<h2>Bienvenido al Sistema de Futbolistas</h2>
<p>Base de datos: <strong>bd_sgp_mockaroo</strong></p>

<div class="row mt-4">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5>Operaciones</h5>
                <ul class="list-unstyled">
                    <li><a href="form_insert.php">Insertar futbolista</a></li>
                    <li><a href="data_select_all.php">Ver todos</a></li>
                    <li><a href="form_select_lastname.php">Buscar por apellido</a></li>
                    <li><a href="form_delete.php">Eliminar por ID</a></li>
                    <li><a href="form_update_lastname.php">Actualizar apellido</a></li>
                    <li><a href="data_select_orderby.php">Ver todos ordenados</a></li>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5>Base de Datos</h5>
                <ul class="list-unstyled">
                    <li><a href="db_create.php">Crear BD y tabla</a></li>
                    <li><a href="data_insert_multiple_prepared.php">Cargar futbolistas</a></li>
                    <li><a href="data_count.php">Ver estadísticas</a></li>
                    <li><a href="table_drop.php">Borrar tabla futbolistas</a></li>
                    <li><a href="table_check_exists.php">Verificar si la tabla de futbolistas existe</a></li>
                    <li><a href="db_drop.php">Borrar la base de datos</a></li>


                </ul>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5>Información</h5>
                <p>Total de futbolistas: <a href="data_count.php">Ver contador</a></p>
                <p>Usuario: <?php echo $_SESSION['usuario']; ?></p>
                <p><a href="logout.php" class="btn btn-sm btn-danger">Cerrar sesión</a></p>
            </div>
        </div>
    </div>
</div>

<?php include "pie.php"; ?>