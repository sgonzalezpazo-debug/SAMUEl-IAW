<?php
// data_update.php - Actualizar apellido de futbolista
include "cabecera.php";
include "recoge.php";

$id = recoge('id');
$nuevo_apellido = recoge('lastname');

if (!$id || !$nuevo_apellido) {
    echo "<div class='alert alert-danger'>ID y nuevo apellido son obligatorios</div>";
    include "pie.php";
    exit();
}

require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Prepared statement para actualizar
$stmt = $conn->prepare("UPDATE Futbolistas SET apellido = ? WHERE id = ?");
$stmt->bind_param("si", $nuevo_apellido, $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo "<div class='alert alert-success'>Apellido actualizado para ID $id</div>";
    } else {
        echo "<div class='alert alert-warning'>No existe futbolista con ID $id</div>";
    }
} else {
    echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
}

$stmt->close();
$conn->close();
?>

<a href="form_update_lastname.php" class="btn btn-primary">Actualizar otro</a>
<a href="data_select_all.php" class="btn btn-secondary">Ver todos</a>
<a href="dashboard.php" class="btn btn-secondary">Inicio</a>

<?php include "pie.php"; ?>