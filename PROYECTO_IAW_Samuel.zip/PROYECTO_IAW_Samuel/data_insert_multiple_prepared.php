<?php
// data_insert_multiple_prepared.php - Insertar múltiples futbolistas
include "cabecera.php";

require_once "config.php";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// 20 FUTBOLISTAS DE EJEMPLO (actualizados y realistas)
$futbolistas = [
    // TOP 5 MÁS VALIOSOS DEL MUNDO
    ["Kylian", "Mbappé", "Delantero", "PSG", "Francia", 25, 180.00],
    ["Erling", "Haaland", "Delantero", "Manchester City", "Noruega", 23, 180.00],
    ["Jude", "Bellingham", "Centrocampista", "Real Madrid", "Inglaterra", 20, 180.00],
    ["Vinícius", "Júnior", "Delantero", "Real Madrid", "Brasil", 23, 150.00],
    
    // PORTEROS TOP
    ["Thibaut", "Courtois", "Portero", "Real Madrid", "Bélgica", 31, 45.00],
    ["Ederson", "Moraes", "Portero", "Manchester City", "Brasil", 30, 40.00],
    ["Jan", "Oblak", "Portero", "Atlético Madrid", "Eslovenia", 31, 35.00],
    ["Marc-André", "ter Stegen", "Portero", "Barcelona", "Alemania", 31, 30.00],
    
    // DEFENSAS DESTACADOS
    ["Virgil", "van Dijk", "Defensa", "Liverpool", "Países Bajos", 32, 35.00],
    ["Rúben", "Dias", "Defensa", "Manchester City", "Portugal", 26, 80.00],
    ["Trent", "Alexander-Arnold", "Defensa", "Liverpool", "Inglaterra", 25, 70.00],
    
    // CENTROCAMPISTAS ESTRELLAS
    ["Kevin", "De Bruyne", "Centrocampista", "Manchester City", "Bélgica", 32, 70.00],
    ["Pedri", "González", "Centrocampista", "Barcelona", "España", 21, 100.00],
    ["Federico", "Valverde", "Centrocampista", "Real Madrid", "Uruguay", 25, 100.00],
    
    // LEYENDAS ACTUALES
    ["Lionel", "Messi", "Delantero", "Inter Miami", "Argentina", 36, 35.00],
    ["Cristiano", "Ronaldo", "Delantero", "Al Nassr", "Portugal", 39, 15.00],
    ["Robert", "Lewandowski", "Delantero", "Barcelona", "Polonia", 35, 30.00],
    
    // JÓVENES PROMESAS
    ["Gavi", "Páez", "Centrocampista", "Barcelona", "España", 19, 90.00],
    ["Julián", "Álvarez", "Delantero", "Manchester City", "Argentina", 24, 80.00],
    ["Rafael", "Leão", "Delantero", "AC Milan", "Portugal", 24, 90.00],
];

// Preparar la consulta
$stmt = $conn->prepare("INSERT INTO Futbolistas (nombre, apellido, posicion, equipo, nacionalidad, edad, valor_mercado) VALUES (?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    echo "<div class='alert alert-danger'>Error preparando consulta: " . $conn->error . "</div>";
    include "pie.php";
    exit();
}

// Variables para bind_param
$nombre = $apellido = $posicion = $equipo = $nacionalidad = $edad = $valor = null;
$stmt->bind_param("sssssid", $nombre, $apellido, $posicion, $equipo, $nacionalidad, $edad, $valor);

$insertados = 0;
$errores = 0;

foreach ($futbolistas as $index => $futbolista) {
    list($nombre, $apellido, $posicion, $equipo, $nacionalidad, $edad, $valor) = $futbolista;
    
    if ($stmt->execute()) {
        $insertados++;
    } else {
        $errores++;
        error_log("Error insertando futbolista " . ($index+1) . ": " . $stmt->error);
    }
}

echo "<div class='alert alert-success'><h4>✅ Datos de ejemplo cargados</h4>";
echo "<p>Se insertaron <strong>$insertados</strong> futbolistas de un total de " . count($futbolistas) . "</p>";
if ($errores > 0) {
    echo "<p class='text-warning'>Hubo $errores errores (consulta el log para detalles)</p>";
}
echo "</div>";

// Estadísticas
echo "<div class='card mt-3'>";
echo "<div class='card-header'><h5>📊 Distribución por posición</h5></div>";
echo "<div class='card-body'>";

$posiciones = ['Portero' => 0, 'Defensa' => 0, 'Centrocampista' => 0, 'Delantero' => 0];
foreach ($futbolistas as $f) {
    $posiciones[$f[2]]++;
}

foreach ($posiciones as $pos => $cantidad) {
    $porcentaje = round(($cantidad / count($futbolistas)) * 100, 1);
    $color = match($pos) {
        'Portero' => 'primary',
        'Defensa' => 'success', 
        'Centrocampista' => 'warning',
        'Delantero' => 'danger',
        default => 'secondary'
    };
    
    echo "<div class='mb-2'>";
    echo "<span class='badge bg-$color me-2'>$pos</span>";
    echo "<small>$cantidad jugadores ($porcentaje%)</small>";
    echo "<div class='progress' style='height: 8px;'>";
    echo "<div class='progress-bar bg-$color' style='width: $porcentaje%'></div>";
    echo "</div></div>";
}
echo "</div></div>";

// Tabla con los 5 más valiosos
echo "<div class='card mt-3'>";
echo "<div class='card-header'><h5>🏆 Top 5 más valiosos</h5></div>";
echo "<div class='card-body'>";
echo "<table class='table table-sm'>";
echo "<tr><th>Jugador</th><th>Equipo</th><th>Valor (€M)</th></tr>";

// Ordenar por valor descendente
usort($futbolistas, function($a, $b) {
    return $b[6] <=> $a[6]; // Comparar por valor (índice 6)
});

for ($i = 0; $i < min(5, count($futbolistas)); $i++) {
    $f = $futbolistas[$i];
    echo "<tr>";
    echo "<td><strong>{$f[0]} {$f[1]}</strong><br><small class='text-muted'>{$f[2]}, {$f[4]}, {$f[5]} años</small></td>";
    echo "<td>{$f[3]}</td>";
    echo "<td class='text-success fw-bold'>€{$f[6]}M</td>";
    echo "</tr>";
}
echo "</table></div></div>";

$stmt->close();
$conn->close();
?>

<div class="mt-4">
    <a href="data_select_all.php" class="btn btn-primary">
        <i class="bi bi-list-ul"></i> Ver todos los futbolistas
    </a>
    <a href="data_count.php" class="btn btn-info">
        <i class="bi bi-bar-chart"></i> Ver estadísticas
    </a>
    <a href="dashboard.php" class="btn btn-secondary">
        <i class="bi bi-house"></i> Volver al inicio
    </a>
</div>

<?php include "pie.php"; ?>