<?php
// config.php - Configuración simple
$servername = "localhost";
$username = "sgp";
$password = "sgp";
$dbname = "bd_sgp_mockaroo";
?>