<?php
// db_drop.php - Eliminar base de datos (con confirmación)
include "cabecera.php";

// Solo si se confirma
if (isset($_POST['confirmar']) && $_POST['confirmar'] === 'SI-BD') {
    require_once "config.php";
    $conn = mysqli_connect($servername, $username, $password);
    
    $sql = "DROP DATABASE IF EXISTS $dbname";
    if (mysqli_query($conn, $sql)) {
        echo "<div class='alert alert-success'>Base de datos '$dbname' eliminada</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
    }
    
    mysqli_close($conn);
    echo "<a href='db_create.php' class='btn btn-primary'>Crear base de datos nueva</a>";
} else {
    // Mostrar formulario de confirmación
    ?>
    <div class="alert alert-danger">
        <h4>⚠️ ¡PELIGRO!</h4>
        <p>Está a punto de eliminar la base de datos</p>
        <p><strong>Esta acción eliminará TODAS las tablas y datos permanentemente.</strong></p>
        
        <form method="post" class="mt-3">
            <p>Para confirmar, escriba "SI-BD" exactamente:</p>
            <input type="text" name="confirmar" class="form-control mb-2" pattern="SI-BD" required>
            <button type="submit" class="btn btn-danger">Eliminar base de datos</button>
            <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
    <?php
}
?>

<?php include "pie.php"; ?>